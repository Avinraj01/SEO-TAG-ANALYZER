import { Code, Search, Share } from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';

interface TabNavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function TabNavigation({ activeTab, setActiveTab }: TabNavigationProps) {
  const isMobile = useIsMobile();

  const tabs = [
    { id: 'meta-tags', label: 'Meta Tags', shortLabel: 'Meta', icon: <Code className="h-4 w-4" /> },
    { id: 'google-preview', label: 'Google Preview', shortLabel: 'Google', icon: <Search className="h-4 w-4" /> },
    { id: 'social-preview', label: 'Social Media Preview', shortLabel: 'Social', icon: <Share className="h-4 w-4" /> },
  ];

  return (
    <div className="mb-6">
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex justify-between sm:justify-start sm:space-x-8">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`whitespace-nowrap py-4 px-2 sm:px-3 border-b-2 font-medium text-sm flex items-center transition-all duration-300 ${
                activeTab === tab.id
                  ? 'border-emerald-500 text-black bg-emerald-400 shadow-lg'
                  : 'border-transparent text-gray-900 hover:text-black hover:bg-emerald-300 hover:border-emerald-500'
              }`}
            >
              <span className="mr-2">{tab.icon}</span>
              <span className="hidden sm:inline">{tab.label}</span>
              <span className="sm:hidden">{tab.shortLabel}</span>
            </button>
          ))}
        </nav>
      </div>
    </div>
  );
}