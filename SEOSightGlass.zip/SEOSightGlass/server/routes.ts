import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSeoAnalysisSchema, seoAnalysisResponseSchema } from "@shared/schema";
import fetch from "node-fetch";
import { JSDOM } from "jsdom";

// Utility function to extract meta tags from HTML
function extractMetaTags(html: string, url: string) {
  const dom = new JSDOM(html);
  const document = dom.window.document;
  
  // Extract title
  const titleTag = document.querySelector('title')?.textContent || '';
  
  // Extract meta tags
  const metaTags: Record<string, string> = {};
  document.querySelectorAll('meta').forEach((meta) => {
    const name = meta.getAttribute('name') || meta.getAttribute('property');
    const content = meta.getAttribute('content');
    if (name && content) {
      metaTags[name] = content;
    }
  });

  // Extract canonical link
  const canonicalLink = document.querySelector('link[rel="canonical"]')?.getAttribute('href') || '';
  
  // Extract charset
  const charsetMeta = document.querySelector('meta[charset]')?.getAttribute('charset');
  
  // Analyze title
  const titleStatus = titleTag ? 
    (titleTag.length > 60 ? 'error' : 
     titleTag.length < 30 ? 'warning' : 'good') : 'error';
  
  // Analyze description
  const description = metaTags['description'] || '';
  const descriptionStatus = description ? 
    (description.length > 160 ? 'error' : 
     description.length < 120 ? 'warning' : 'good') : 'error';
  
  // Analyze canonical
  const canonicalStatus = canonicalLink ? 
    (canonicalLink.includes(url) ? 'good' : 'warning') : 'error';
  
  // Analyze robots
  const robots = metaTags['robots'] || '';
  const robotsStatus = robots ? 
    (robots.includes('noindex') ? 'error' : 'good') : 'warning';
  
  // Analyze charset
  const charset = charsetMeta || metaTags['charset'] || '';
  const charsetStatus = charset ? 
    (charset.toLowerCase() === 'utf-8' ? 'good' : 'warning') : 'error';
  
  // Analyze viewport
  const viewport = metaTags['viewport'] || '';
  const viewportStatus = viewport ? 
    (viewport.includes('width=device-width') ? 'good' : 'warning') : 'error';
  
  // Analyze Open Graph title
  const ogTitle = metaTags['og:title'] || '';
  const ogTitleStatus = ogTitle ? 'good' : 'warning';
  
  // Analyze Open Graph description
  const ogDescription = metaTags['og:description'] || '';
  const ogDescriptionStatus = ogDescription ? 'good' : 'warning';
  
  // Analyze Open Graph image
  const ogImage = metaTags['og:image'] || '';
  const ogImageStatus = ogImage ? 'good' : 'warning';
  
  // Analyze Open Graph type
  const ogType = metaTags['og:type'] || '';
  const ogTypeStatus = ogType ? 'good' : 'warning';
  
  // Analyze Twitter card
  const twitterCard = metaTags['twitter:card'] || '';
  const twitterCardStatus = twitterCard ? 'good' : 'warning';
  
  // Analyze Twitter title
  const twitterTitle = metaTags['twitter:title'] || '';
  const twitterTitleStatus = twitterTitle ? 'good' : 'warning';
  
  // Analyze Twitter description
  const twitterDescription = metaTags['twitter:description'] || '';
  const twitterDescriptionStatus = twitterDescription ? 'good' : 'warning';
  
  // Analyze Twitter image
  const twitterImage = metaTags['twitter:image'] || '';
  const twitterImageStatus = twitterImage ? 'good' : 'warning';
  
  // Calculate statistics
  const criticalIssues = [
    titleStatus, descriptionStatus, canonicalStatus, robotsStatus, 
    charsetStatus, viewportStatus
  ].filter(status => status === 'error').length;
  
  const warnings = [
    titleStatus, descriptionStatus, canonicalStatus, robotsStatus, 
    charsetStatus, viewportStatus, ogTitleStatus, ogDescriptionStatus, 
    ogImageStatus, ogTypeStatus, twitterCardStatus, twitterTitleStatus, 
    twitterDescriptionStatus, twitterImageStatus
  ].filter(status => status === 'warning').length;
  
  const passedChecks = [
    titleStatus, descriptionStatus, canonicalStatus, robotsStatus, 
    charsetStatus, viewportStatus, ogTitleStatus, ogDescriptionStatus, 
    ogImageStatus, ogTypeStatus, twitterCardStatus, twitterTitleStatus, 
    twitterDescriptionStatus, twitterImageStatus
  ].filter(status => status === 'good').length;
  
  // Calculate overall score (simple algorithm)
  const totalChecks = 14; // Total number of checks we perform
  const weightedScore = 
    (passedChecks * 100 + (totalChecks - passedChecks - criticalIssues) * 50) / totalChecks;
  const overallScore = Math.round(Math.max(0, Math.min(100, weightedScore)));
  
  return {
    url,
    overallScore,
    criticalIssues,
    warnings,
    passedChecks,
    metaTags: {
      title: { value: titleTag, status: titleStatus },
      description: { value: description, status: descriptionStatus },
      canonical: { value: canonicalLink, status: canonicalStatus },
      robots: { value: robots, status: robotsStatus },
      charset: { value: charset, status: charsetStatus },
      viewport: { value: viewport, status: viewportStatus },
      ogTitle: { value: ogTitle, status: ogTitleStatus },
      ogDescription: { value: ogDescription, status: ogDescriptionStatus },
      ogImage: { value: ogImage, status: ogImageStatus },
      ogType: { value: ogType, status: ogTypeStatus },
      twitterCard: { value: twitterCard, status: twitterCardStatus },
      twitterTitle: { value: twitterTitle, status: twitterTitleStatus },
      twitterDescription: { value: twitterDescription, status: twitterDescriptionStatus },
      twitterImage: { value: twitterImage, status: twitterImageStatus },
    }
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // put application routes here
  // prefix all routes with /api

  // Endpoint to analyze a URL's SEO meta tags
  app.post('/api/analyze', async (req, res) => {
    try {
      // Validate the request body
      const validatedData = insertSeoAnalysisSchema.parse(req.body);
      const { url } = validatedData;
      
      // Store the analysis request
      const analysis = await storage.createAnalysis({ url });
      
      try {
        // Fetch the HTML content from the URL
        const response = await fetch(url, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (compatible; SEOAnalyzer/1.0;)'
          }
        });
        
        if (!response.ok) {
          return res.status(400).json({ 
            message: `Failed to fetch URL: ${response.status} ${response.statusText}`
          });
        }
        
        const html = await response.text();
        
        // Extract and analyze the meta tags
        const analysisResult = extractMetaTags(html, url);
        
        // Validate the response against our schema
        const validatedResult = seoAnalysisResponseSchema.parse(analysisResult);
        
        // Return the analysis results
        return res.status(200).json(validatedResult);
      } catch (error) {
        console.error('Error fetching or processing URL:', error);
        return res.status(500).json({ 
          message: 'Error processing URL. Please ensure the URL is valid and accessible.'
        });
      }
    } catch (error) {
      console.error('Error validating request:', error);
      return res.status(400).json({ 
        message: 'Invalid request data. Please provide a valid URL.'
      });
    }
  });

  // Get analysis history
  app.get('/api/history', async (req, res) => {
    try {
      const history = await storage.getAnalysisHistory();
      return res.status(200).json(history);
    } catch (error) {
      console.error('Error fetching history:', error);
      return res.status(500).json({ message: 'Failed to fetch analysis history' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
