import { MetaTag } from '@shared/schema';
import { CheckCircle, AlertCircle, XCircle } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';

interface CategorySummaryProps {
  title: string;
  icon: React.ReactNode;
  tags: MetaTag[];
  description: string;
}

export default function CategorySummary({ title, icon, tags, description }: CategorySummaryProps) {
  // Count issues by status
  const counts = tags.reduce(
    (acc, tag) => {
      acc[tag.status]++;
      return acc;
    },
    { good: 0, warning: 0, error: 0 } as Record<string, number>
  );

  // Calculate the score for this category
  const totalTags = tags.length;
  const weightedScore = ((counts.good * 100 + counts.warning * 50) / totalTags) || 0;
  const score = Math.round(Math.max(0, Math.min(100, weightedScore)));
  
  // Determine color based on score
  const getScoreColorClass = () => {
    if (score < 50) return 'text-red-500';
    if (score >= 80) return 'text-emerald-500';
    return 'text-amber-500';
  };
  
  const getProgressColorClass = () => {
    if (score < 50) return 'bg-red-500';
    if (score >= 80) return 'bg-emerald-500';
    return 'bg-amber-500';
  };

  // Generate summary text
  const getSummaryText = () => {
    if (counts.error > 0) {
      return `${counts.error} critical issue${counts.error !== 1 ? 's' : ''} to fix`;
    } else if (counts.warning > 0) {
      return `${counts.warning} warning${counts.warning !== 1 ? 's' : ''} to improve`;
    } else {
      return "All checks passed!";
    }
  };

  // Get appropriate icon
  const getStatusIcon = () => {
    if (counts.error > 0) {
      return <XCircle className="h-4 w-4 text-red-500" />;
    } else if (counts.warning > 0) {
      return <AlertCircle className="h-4 w-4 text-amber-500" />;
    } else {
      return <CheckCircle className="h-4 w-4 text-emerald-500" />;
    }
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-200">
      <div className="flex items-center mb-2">
        <div className="mr-2 text-primary">{icon}</div>
        <h4 className="font-medium">{title}</h4>
      </div>
      
      <p className="text-xs text-gray-500 mb-3">{description}</p>
      
      <div className="flex items-center gap-2 mb-2">
        <span className={`text-lg font-bold ${getScoreColorClass()}`}>{score}%</span>
        <div className="flex-grow">
          <Progress 
            value={score} 
            className={cn("h-2", getProgressColorClass())} 
          />
        </div>
      </div>
      
      <div className="flex items-center justify-between mt-3">
        <div className="flex items-center gap-1 text-xs text-gray-600">
          {getStatusIcon()}
          <span>{getSummaryText()}</span>
        </div>
        
        <div className="flex gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
          <span className="text-xs text-gray-600">{counts.good}</span>
          {counts.warning > 0 && (
            <>
              <div className="w-2 h-2 rounded-full bg-amber-500"></div>
              <span className="text-xs text-gray-600">{counts.warning}</span>
            </>
          )}
          {counts.error > 0 && (
            <>
              <div className="w-2 h-2 rounded-full bg-red-500"></div>
              <span className="text-xs text-gray-600">{counts.error}</span>
            </>
          )}
        </div>
      </div>
    </div>
  );
}