import { MetaTag } from '@shared/schema';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { CheckCircle, AlertCircle, XCircle, HelpCircle, Copy } from 'lucide-react';
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';

interface MetaTagItemProps {
  title: string;
  type: string;
  tag: MetaTag;
  goodDescription: string;
  warningDescription: string;
  errorDescription: string;
  tooltip: string;
}

export default function MetaTagItem({
  title,
  type,
  tag,
  goodDescription,
  warningDescription,
  errorDescription,
  tooltip,
}: MetaTagItemProps) {
  const { toast } = useToast();
  const [isExpanded, setIsExpanded] = useState(false);

  // Determine status styles
  const getStatusStyles = () => {
    switch (tag.status) {
      case 'good':
        return {
          icon: <CheckCircle className="h-5 w-5 text-emerald-500" />,
          text: 'text-emerald-700',
          border: 'border-emerald-200',
          bg: 'bg-emerald-50',
          hoverBg: 'bg-emerald-100',
          hoverText: 'text-white'
        };
      case 'warning':
        return {
          icon: <AlertCircle className="h-5 w-5 text-amber-500" />,
          text: 'text-amber-700',
          border: 'border-amber-200',
          bg: 'bg-amber-50',
          hoverBg: 'bg-amber-100',
          hoverText: 'text-white'
        };
      case 'error':
        return {
          icon: <XCircle className="h-5 w-5 text-red-500" />,
          text: 'text-red-700',
          border: 'border-red-200',
          bg: 'bg-red-50',
          hoverBg: 'bg-red-100',
          hoverText: 'text-white'
        };
      default:
        return {
          icon: null,
          text: 'text-gray-700',
          border: 'border-gray-200',
          bg: 'bg-gray-50',
          hoverBg: 'bg-gray-100',
          hoverText: 'text-gray-900'
        };
    }
  };

  // Get description based on status
  const getDescription = () => {
    switch (tag.status) {
      case 'good':
        return goodDescription;
      case 'warning':
        return warningDescription;
      case 'error':
        return errorDescription;
      default:
        return '';
    }
  };

  const styles = getStatusStyles();

  // Copy tag value to clipboard
  const copyToClipboard = () => {
    if (tag.value) {
      navigator.clipboard.writeText(tag.value);
      toast({
        title: "Copied to clipboard",
        description: `${title} has been copied to your clipboard.`,
        duration: 3000,
      });
    }
  };

  // Truncate text if it's too long
  const truncateText = (text: string, limit: number) => {
    if (!text) return '';
    if (text.length <= limit) return text;
    return text.slice(0, limit) + '...';
  };

  return (
    <div className={`p-4 rounded-lg border ${styles.border} ${styles.bg} transition-all hover:${styles.hoverBg} group`}>
      <div className="flex justify-between items-start">
        <div className="flex items-start">
          <span className="mr-2 mt-1 flex-shrink-0">
            {styles.icon}
          </span>
          <div>
            <h5 className={`font-medium ${styles.text}`}>{title}</h5>
            <p className="text-sm text-gray-600">
              {getDescription()}
            </p>
          </div>
        </div>
        <div className="flex items-center">
          {tag.value && (
            <button 
              onClick={copyToClipboard} 
              className={`mr-2 text-gray-400 hover:text-gray-600 transition-all group-hover:${styles.hoverText}`}
              aria-label="Copy to clipboard"
            >
              <Copy className="h-4 w-4" />
            </button>
          )}
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <button className={`text-gray-400 hover:text-gray-600 transition-all group-hover:${styles.hoverText}`}>
                  <HelpCircle className="h-4 w-4" />
                </button>
              </TooltipTrigger>
              <TooltipContent className="max-w-xs p-3 text-xs bg-gray-800 text-white">
                <p>{tooltip}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>

      <div className="mt-3">
        <div 
          className={`bg-white p-3 border border-gray-200 rounded text-sm font-mono relative cursor-pointer transition-all hover:${styles.hoverBg} group`}
          onClick={() => setIsExpanded(!isExpanded)}
        >
          <div className={isExpanded ? '' : 'line-clamp-2'}>
            <span className={`${styles.text}`}>{tag.value || `No ${type} found`}</span>
          </div>
          {tag.value && tag.value.length > 100 && !isExpanded && (
            <div className="absolute bottom-0 right-0 left-0 flex justify-center text-xs text-blue-500 bg-white bg-opacity-80 px-2 pt-1 pb-0.5">
              Click to expand
            </div>
          )}
        </div>
      </div>

      {/* Recommendations specific to the tag */}
      {tag.status !== 'good' && (
        <div className="mt-2 text-xs">
          {type === 'title' && tag.status === 'error' && (
            <p className="text-red-600">Optimal title length: 50-60 characters</p>
          )}
          {type === 'description' && tag.status === 'error' && (
            <p className="text-red-600">Optimal description length: 120-160 characters</p>
          )}
        </div>
      )}
    </div>
  );
}