import { SeoAnalysisResponse } from '@shared/schema';
import { Facebook, Twitter, ImageOff, CheckCircle, AlertTriangle, Info } from 'lucide-react';

interface SocialPreviewTabProps {
  analysisResult: SeoAnalysisResponse;
}

export default function SocialPreviewTab({ analysisResult }: SocialPreviewTabProps) {
  const { url, metaTags } = analysisResult;

  // Helper to display domain
  const displayUrl = () => {
    try {
      const urlObj = new URL(url);
      return urlObj.hostname;
    } catch (e) {
      return url;
    }
  };

  // Get best available title and description for each platform
  const facebookTitle = metaTags.ogTitle.value || metaTags.title.value || 'No title available';
  const facebookDescription = metaTags.ogDescription.value || metaTags.description.value || 'No description available';
  const facebookImage = metaTags.ogImage.value;

  const twitterTitle = metaTags.twitterTitle.value || metaTags.ogTitle.value || metaTags.title.value || 'No title available';
  const twitterDescription = metaTags.twitterDescription.value || metaTags.ogDescription.value || metaTags.description.value || 'No description available';
  const twitterImage = metaTags.twitterImage.value || metaTags.ogImage.value;
  const twitterCardType = metaTags.twitterCard.value || 'summary';

  // Check if twitter tags are properly implemented
  const hasTwitterTags = metaTags.twitterCard.value && 
    (metaTags.twitterTitle.value || metaTags.ogTitle.value) &&
    (metaTags.twitterDescription.value || metaTags.ogDescription.value) &&
    (metaTags.twitterImage.value || metaTags.ogImage.value);

  // Check if facebook tags are properly implemented
  const hasFacebookTags = metaTags.ogTitle.value && 
    metaTags.ogDescription.value && 
    metaTags.ogImage.value && 
    metaTags.ogType.value;

  // Check if URL is a YouTube video
  const isYouTubeUrl = () => {
    try {
      const urlObj = new URL(url);
      return urlObj.hostname.includes('youtube.com') || urlObj.hostname.includes('youtu.be');
    } catch (e) {
      return false;
    }
  };

  // Get YouTube video ID
  const getYouTubeVideoId = () => {
    try {
      const urlObj = new URL(url);
      if (urlObj.hostname.includes('youtube.com')) {
        return urlObj.searchParams.get('v');
      } else if (urlObj.hostname.includes('youtu.be')) {
        return urlObj.pathname.slice(1);
      }
      return null;
    } catch (e) {
      return null;
    }
  };


  return (
    <div className="bg-white p-4 sm:p-6 rounded-lg shadow-sm border border-gray-200">
      <h3 className="text-lg font-semibold mb-4">Social Media Preview</h3>
      <p className="text-sm text-gray-500 mb-6">
        Preview how your page will appear when shared on social media platforms based on Open Graph and Twitter Card meta tags.
      </p>

      <div className="space-y-8 max-w-2xl mx-auto">
        {/* LinkedIn Preview */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <a 
              href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-md font-medium flex items-center hover:text-blue-600 transition-colors"
            >
              <svg className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.32 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.79M6.88 8.56a1.68 1.68 0 0 0 1.68-1.68c0-.93-.75-1.69-1.68-1.69a1.69 1.69 0 0 0-1.69 1.69c0 .93.76 1.68 1.69 1.68m1.39 9.94v-8.37H5.5v8.37h2.77z"/>
              </svg>
              LinkedIn Preview
            </a>
          </div>
          <div className="border border-gray-300 rounded-lg overflow-hidden bg-white shadow-sm">
            <div className="h-40 sm:h-52 bg-gray-100 flex items-center justify-center">
              {facebookImage ? (
                <img 
                  src={facebookImage} 
                  alt="LinkedIn preview image" 
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.onerror = null;
                    target.src = 'data:image/svg+xml;charset=UTF-8,%3Csvg width=\'100%\' height=\'100%\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Crect width=\'100%\' height=\'100%\' fill=\'%23f3f4f6\'/%3E%3Ctext x=\'50%\' y=\'50%\' dominant-baseline=\'middle\' text-anchor=\'middle\' font-family=\'Arial\' font-size=\'16px\' fill=\'%236b7280\'%3EImage not available%3C/text%3E%3C/svg%3E';
                  }}
                />
              ) : (
                <div className="text-center text-gray-500">
                  <ImageOff className="h-12 w-12 mx-auto mb-2" />
                  <p className="text-sm">No Open Graph image available</p>
                </div>
              )}
            </div>
            <div className="p-3">
              <div className="text-xs text-gray-500 uppercase mb-1">{displayUrl()}</div>
              <h5 className="font-bold text-gray-900 mb-1 line-clamp-2">{facebookTitle}</h5>
              <p className="text-sm text-gray-600 mb-1 line-clamp-3">{facebookDescription}</p>
            </div>
          </div>
        </div>
        {/* Facebook Preview */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <a 
              href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-md font-medium flex items-center hover:text-blue-600 transition-colors"
            >
              <Facebook className="h-4 w-4 mr-2" />
              Facebook Preview
            </a>
            <div className="flex items-center">
              {hasFacebookTags ? (
                <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full flex items-center">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Well configured
                </span>
              ) : (
                <span className="text-xs bg-amber-100 text-amber-800 px-2 py-1 rounded-full flex items-center">
                  <AlertTriangle className="h-3 w-3 mr-1" />
                  Missing tags
                </span>
              )}
            </div>
          </div>

          <div className="border border-gray-300 rounded-lg overflow-hidden bg-white shadow-sm">
            {/* Image preview */}
            <div className="h-40 sm:h-52 bg-gray-100 flex items-center justify-center">
              {facebookImage ? (
                <img 
                  src={facebookImage} 
                  alt="Open Graph image" 
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.onerror = null;
                    target.src = 'data:image/svg+xml;charset=UTF-8,%3Csvg width=\'100%\' height=\'100%\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Crect width=\'100%\' height=\'100%\' fill=\'%23f3f4f6\'/%3E%3Ctext x=\'50%\' y=\'50%\' dominant-baseline=\'middle\' text-anchor=\'middle\' font-family=\'Arial\' font-size=\'16px\' fill=\'%236b7280\'%3EImage not available%3C/text%3E%3C/svg%3E';
                  }}
                />
              ) : (
                <div className="text-center text-gray-500">
                  <ImageOff className="h-12 w-12 mx-auto mb-2" />
                  <p className="text-sm">No Open Graph image available</p>
                </div>
              )}
            </div>

            {/* Content preview */}
            <div className="p-3">
              <div className="text-xs text-gray-500 uppercase mb-1">{displayUrl()}</div>
              <h5 className="font-bold text-gray-900 mb-1 line-clamp-2">{facebookTitle}</h5>
              <p className="text-sm text-gray-600 mb-1 line-clamp-3">{facebookDescription}</p>
            </div>
          </div>

          {/* Recommendations */}
          {!hasFacebookTags && (
            <div className="mt-4 p-3 bg-gray-50 rounded-lg border border-gray-200 text-sm">
              <h5 className="font-medium mb-2 flex items-center">
                <Info className="h-4 w-4 mr-1 text-blue-500" />
                Recommendations for Facebook:
              </h5>
              <ul className="list-disc list-inside space-y-1 text-gray-600">
                {!metaTags.ogTitle.value && <li>Add an og:title meta tag</li>}
                {!metaTags.ogDescription.value && <li>Add an og:description meta tag</li>}
                {!metaTags.ogImage.value && <li>Add an og:image meta tag (recommended size: 1200×630 pixels)</li>}
                {!metaTags.ogType.value && <li>Add an og:type meta tag (e.g., website, article)</li>}
              </ul>
            </div>
          )}
        </div>

        {/* Twitter Preview */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <a 
              href={`https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(twitterTitle)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-md font-medium flex items-center hover:text-blue-600 transition-colors"
            >
              <Twitter className="h-4 w-4 mr-2" />
              Twitter Preview
            </a>
            <div className="flex items-center">
              {hasTwitterTags ? (
                <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full flex items-center">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Well configured
                </span>
              ) : (
                <span className="text-xs bg-amber-100 text-amber-800 px-2 py-1 rounded-full flex items-center">
                  <AlertTriangle className="h-3 w-3 mr-1" />
                  Missing tags
                </span>
              )}
            </div>
          </div>

          <div className="border border-gray-300 rounded-lg overflow-hidden bg-white shadow-sm">
            {/* Image preview (only for summary_large_image) */}
            {twitterCardType === 'summary_large_image' && (
              <div className="h-40 sm:h-52 bg-gray-100 flex items-center justify-center">
                {twitterImage ? (
                  <img 
                    src={twitterImage} 
                    alt="Twitter card image" 
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.onerror = null;
                      target.src = 'data:image/svg+xml;charset=UTF-8,%3Csvg width=\'100%\' height=\'100%\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Crect width=\'100%\' height=\'100%\' fill=\'%23f3f4f6\'/%3E%3Ctext x=\'50%\' y=\'50%\' dominant-baseline=\'middle\' text-anchor=\'middle\' font-family=\'Arial\' font-size=\'16px\' fill=\'%236b7280\'%3EImage not available%3C/text%3E%3C/svg%3E';
                    }}
                  />
                ) : (
                  <div className="text-center text-gray-500">
                    <ImageOff className="h-12 w-12 mx-auto mb-2" />
                    <p className="text-sm">No Twitter card image available</p>
                  </div>
                )}
              </div>
            )}

            {/* Content preview */}
            <div className="p-3 flex">
              {/* Small image for summary card type */}
              {(twitterCardType === 'summary' || !twitterCardType) && (
                <div className="mr-3 flex-shrink-0">
                  <div className="w-16 h-16 bg-gray-100 rounded overflow-hidden flex items-center justify-center">
                    {twitterImage ? (
                      <img 
                        src={twitterImage} 
                        alt="Twitter card image" 
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.onerror = null;
                          target.src = 'data:image/svg+xml;charset=UTF-8,%3Csvg width=\'100%\' height=\'100%\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Crect width=\'100%\' height=\'100%\' fill=\'%23f3f4f6\'/%3E%3Ctext x=\'50%\' y=\'50%\' dominant-baseline=\'middle\' text-anchor=\'middle\' font-family=\'Arial\' font-size=\'10px\' fill=\'%236b7280\'%3ENo image%3C/text%3E%3C/svg%3E';
                        }}
                      />
                    ) : (
                      <ImageOff className="h-4 w-4 text-gray-400" />
                    )}
                  </div>
                </div>
              )}

              <div className="flex-1 min-w-0">
                <div className="text-xs text-gray-500 mb-1 truncate">{displayUrl()}</div>
                <h5 className="font-bold text-gray-900 mb-1 line-clamp-2">{twitterTitle}</h5>
                <p className="text-sm text-gray-600 line-clamp-2">{twitterDescription}</p>
              </div>
            </div>
          </div>

          {/* Recommendations */}
          {!hasTwitterTags && (
            <div className="mt-4 p-3 bg-gray-50 rounded-lg border border-gray-200 text-sm">
              <h5 className="font-medium mb-2 flex items-center">
                <Info className="h-4 w-4 mr-1 text-blue-500" />
                Recommendations for Twitter:
              </h5>
              <ul className="list-disc list-inside space-y-1 text-gray-600">
                {!metaTags.twitterCard.value && <li>Add a twitter:card meta tag (summary, summary_large_image, app, or player)</li>}
                {!metaTags.twitterTitle.value && !metaTags.ogTitle.value && <li>Add a twitter:title meta tag (or at least og:title)</li>}
                {!metaTags.twitterDescription.value && !metaTags.ogDescription.value && <li>Add a twitter:description meta tag (or at least og:description)</li>}
                {!metaTags.twitterImage.value && !metaTags.ogImage.value && <li>Add a twitter:image meta tag (or at least og:image)</li>}
              </ul>
            </div>
          )}
        </div>

        {/* YouTube Preview */}
        {isYouTubeUrl() && (
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-md font-medium flex items-center">
                <img src="/youtube-logo.svg" alt="YouTube Logo" className="h-4 w-4 mr-2" />
                YouTube Preview
              </h4>
            </div>
            <div className="aspect-video w-full">
              <iframe 
                width="560" 
                height="315" 
                src={`https://www.youtube.com/embed/${getYouTubeVideoId()}`} 
                title="YouTube video player" 
                frameborder="0" 
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
                allowfullscreen
              ></iframe>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}