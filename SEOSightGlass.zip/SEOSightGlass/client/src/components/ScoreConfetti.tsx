
import { useEffect, useState } from 'react';
import Confetti from 'react-confetti';

interface ScoreConfettiProps {
  score: number;
  threshold?: number;
}

export default function ScoreConfetti({ score, threshold = 80 }: ScoreConfettiProps) {
  const [showConfetti, setShowConfetti] = useState(false);
  const [windowSize, setWindowSize] = useState({
    width: window.innerWidth,
    height: window.innerHeight,
  });

  useEffect(() => {
    if (score >= threshold) {
      setShowConfetti(true);
      const timer = setTimeout(() => setShowConfetti(false), 5000);
      return () => clearTimeout(timer);
    }
  }, [score, threshold]);

  useEffect(() => {
    const handleResize = () => {
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  if (!showConfetti) return null;

  return (
    <Confetti
      width={windowSize.width}
      height={200} // Reduced height to contain confetti near the header
      numberOfPieces={150}
      recycle={false}
      style={{ 
        position: 'absolute',
        top: '100%', // Position below the header
        left: 0,
        zIndex: 10 
      }}
    />
  );
}
