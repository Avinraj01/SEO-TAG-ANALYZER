import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Link as LinkIcon, ArrowRight } from "lucide-react";
import { apiRequest } from '@/lib/queryClient';
import { useMutation } from '@tanstack/react-query';
import { SeoAnalysisResponse } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { useIsMobile } from '@/hooks/use-mobile';

interface URLInputProps {
  onAnalysisComplete: (result: SeoAnalysisResponse) => void;
}

export default function URLInput({ onAnalysisComplete }: URLInputProps) {
  const [url, setUrl] = useState('');
  const [urlError, setUrlError] = useState('');
  const { toast } = useToast();
  const isMobile = useIsMobile();

  const analyzeUrlMutation = useMutation({
    mutationFn: async (urlToAnalyze: string) => {
      const response = await apiRequest('POST', '/api/analyze', { url: urlToAnalyze });
      return response.json();
    },
    onSuccess: (data: SeoAnalysisResponse) => {
      onAnalysisComplete(data);
      toast({
        title: "Analysis complete",
        description: `We've analyzed ${data.url} successfully.`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Analysis failed",
        description: error.message || "Failed to analyze URL. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleAnalyzeUrl = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate URL
    if (!url) {
      setUrlError('Please enter a URL');
      return;
    }
    
    try {
      // If URL doesn't have protocol, add https://
      const urlToCheck = url.startsWith('http://') || url.startsWith('https://') 
        ? url 
        : `https://${url}`;
      
      new URL(urlToCheck);
      setUrlError('');
      
      // Trigger analysis with fixed URL if needed
      analyzeUrlMutation.mutate(urlToCheck);
    } catch (e) {
      setUrlError('Please enter a valid URL');
      return;
    }
  };

  return (
    <div className="mb-8 bg-black p-4 sm:p-6 rounded-lg shadow-sm border border-gray-200">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4 gap-2">
        <h2 className="text-lg font-semibold text-white">Enter a URL to analyze SEO meta tags</h2>
        {!isMobile && (
          <div className="bg-gray-50 px-3 py-1 rounded-md border border-gray-200 text-xs text-gray-600 flex items-center">
            <span className="hidden md:inline">Free analysis tool</span>
            <span className="md:hidden">Free tool</span>
            <span className="ml-1 inline-flex items-center px-1.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
              No signup required
            </span>
          </div>
        )}
      </div>
      
      <form onSubmit={handleAnalyzeUrl} className="flex flex-col sm:flex-row gap-3">
        <div className="flex-grow relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <LinkIcon className="h-4 w-4 text-gray-400" />
          </div>
          <Input
            type="text"
            value={url}
            onChange={(e) => {
              setUrl(e.target.value);
              if (urlError) setUrlError('');
            }}
            placeholder="example.com or https://example.com"
            required
            className={`pl-10 pr-4 h-11 ${urlError ? 'border-red-300 focus:ring-red-500' : ''}`}
          />
          {urlError && (
            <div className="mt-1 text-sm text-red-500 absolute">
              {urlError}
            </div>
          )}
        </div>
        <Button 
          type="submit" 
          disabled={analyzeUrlMutation.isPending}
          className="h-11 min-w-28 transition-all duration-200"
          size="lg"
        >
          {analyzeUrlMutation.isPending ? (
            <>
              <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"></div>
              <span className="hidden sm:inline">Analyzing...</span>
              <span className="sm:hidden">Analyzing</span>
            </>
          ) : (
            <>
              <Search className="mr-2 h-4 w-4" />
              <span className="hidden sm:inline">Analyze SEO</span>
              <span className="sm:hidden">Analyze</span>
            </>
          )}
        </Button>
      </form>
      
      <div className="mt-6 text-xs text-gray-500 flex items-start gap-2">
        <InfoTip 
          title="Quick Tips"
          content={
            <>
              <p>• Enter any website URL to analyze its SEO meta tags</p>
              <p>• You can skip 'https://' - we'll add it automatically</p>
              <p>• Results show Google and social media previews</p>
            </>
          }
        />
      </div>
    </div>
  );
}

function InfoTip({ title, content }: { title: string, content: React.ReactNode }) {
  return (
    <div className="bg-blue-50 border border-blue-200 rounded-md p-2 text-xs text-blue-800">
      <div className="font-medium mb-1">{title}</div>
      <div className="text-blue-700">{content}</div>
    </div>
  );
}
