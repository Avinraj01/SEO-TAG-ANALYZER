import { SeoAnalysisResponse } from '@shared/schema';
import { Monitor, Smartphone, InfoIcon, ScanSearch } from 'lucide-react';

interface GooglePreviewTabProps {
  analysisResult: SeoAnalysisResponse;
}

export default function GooglePreviewTab({ analysisResult }: GooglePreviewTabProps) {
  const { url, metaTags } = analysisResult;

  // Format the domain for display
  const displayUrl = () => {
    try {
      const urlObj = new URL(url);
      return urlObj.hostname + urlObj.pathname;
    } catch (e) {
      return url;
    }
  };

  // Get breadcrumbs if available
  const getBreadcrumbs = () => {
    try {
      const urlObj = new URL(url);
      if (urlObj.pathname === "/" || !urlObj.pathname) return null;
      
      const parts = urlObj.pathname.split('/').filter(Boolean);
      if (parts.length <= 1) return null;
      
      return parts.join(' › ');
    } catch {
      return null;
    }
  };

  // Default description for when no description is available
  const defaultDescription = "No description available. Google may generate a description from the page content or display none at all.";
  
  // Determine if meta tags are properly optimized
  const titleIsOptimal = metaTags.title.status === 'good';
  const descriptionIsOptimal = metaTags.description.status === 'good';

  return (
    <div className="bg-white p-4 sm:p-6 rounded-lg shadow-sm border border-gray-200">
      <h3 className="text-lg font-semibold mb-4">Google Search Results Preview</h3>
      <p className="text-sm text-gray-500 mb-6">
        This is how your page might appear in Google search results based on your meta tags.
      </p>
      
      <div className="max-w-2xl mx-auto">
        {/* Google Desktop Preview */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-md font-medium flex items-center">
              <Monitor className="h-4 w-4 mr-2" />
              Desktop Preview
            </h4>
            
            {!titleIsOptimal || !descriptionIsOptimal ? (
              <span className="text-xs bg-amber-100 text-amber-800 px-2 py-1 rounded-full">
                Needs optimization
              </span>
            ) : (
              <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">
                Well optimized
              </span>
            )}
          </div>
          
          <div className="border border-gray-200 rounded-lg p-4 bg-white shadow-sm">
            {/* URL and breadcrumbs */}
            <div className="flex flex-col">
              <div className="text-xs text-green-800 mb-1 truncate">{displayUrl()}</div>
              {getBreadcrumbs() && (
                <div className="text-xs text-gray-500 mb-1">{getBreadcrumbs()}</div>
              )}
            </div>
            
            {/* Title */}
            <h5 className="text-xl text-blue-700 font-medium mb-1 hover:underline cursor-pointer line-clamp-2">
              {metaTags.title.value || 'No title available'}
            </h5>
            
            {/* Description */}
            <p className="text-sm text-gray-600 line-clamp-3">
              {metaTags.description.value || defaultDescription}
            </p>
            
            {/* Optional: Site links simulation */}
            {metaTags.title.status === 'good' && metaTags.description.status === 'good' && (
              <div className="mt-2 grid grid-cols-2 gap-x-4 gap-y-1">
                <a href="#" className="text-sm text-blue-700 hover:underline truncate">About</a>
                <a href="#" className="text-sm text-blue-700 hover:underline truncate">Services</a>
                <a href="#" className="text-sm text-blue-700 hover:underline truncate">Contact</a>
                <a href="#" className="text-sm text-blue-700 hover:underline truncate">Blog</a>
              </div>
            )}
          </div>
          
          {/* SEO Status indicators */}
          <div className="mt-3 flex flex-wrap gap-2">
            <div className={`text-xs px-2 py-1 rounded-full flex items-center ${
              titleIsOptimal ? 'bg-green-50 text-green-700' : 'bg-amber-50 text-amber-700'
            }`}>
              <span className="w-2 h-2 mr-1 rounded-full bg-current"></span>
              Title: {titleIsOptimal ? 'Optimal' : 'Needs improvement'}
            </div>
            
            <div className={`text-xs px-2 py-1 rounded-full flex items-center ${
              descriptionIsOptimal ? 'bg-green-50 text-green-700' : 'bg-amber-50 text-amber-700'
            }`}>
              <span className="w-2 h-2 mr-1 rounded-full bg-current"></span>
              Description: {descriptionIsOptimal ? 'Optimal' : 'Needs improvement'}
            </div>
          </div>
        </div>
        
        {/* Google Mobile Preview */}
        <div>
          <h4 className="text-md font-medium mb-3 flex items-center">
            <Smartphone className="h-4 w-4 mr-2" />
            Mobile Preview
          </h4>
          <div className="max-w-xs border border-gray-200 rounded-lg p-3 bg-white shadow-sm">
            {/* URL and breadcrumbs */}
            <div className="text-xs text-green-800 mb-1 truncate">{displayUrl()}</div>
            
            {/* Title */}
            <h5 className="text-base text-blue-700 font-medium mb-1 hover:underline cursor-pointer line-clamp-2">
              {metaTags.title.value || 'No title available'}
            </h5>
            
            {/* Description */}
            <p className="text-xs text-gray-600 line-clamp-3">
              {metaTags.description.value || defaultDescription}
            </p>
          </div>
        </div>
      </div>
      
      <div className="mt-8 p-4 bg-gray-50 rounded-lg border border-gray-200">
        <h4 className="text-md font-medium mb-2 flex items-center">
          <InfoIcon className="h-4 w-4 text-amber-500 mr-2" />
          Important Note
        </h4>
        <p className="text-sm text-gray-600">
          This is a simulation of how your page might appear in Google search results. 
          Actual results may vary as Google can dynamically modify titles and descriptions 
          based on the search query and other factors. For the most accurate preview, 
          use Google Search Console.
        </p>
      </div>
      
      {/* SEO Optimization Tips */}
      <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
        <h4 className="text-md font-medium mb-2 flex items-center text-blue-800">
          <ScanSearch className="h-4 w-4 text-blue-500 mr-2" />
          SEO Optimization Tips
        </h4>
        <div className="text-sm text-blue-700 space-y-2">
          <p>
            <strong>Title Tag:</strong> Aim for 50-60 characters. Include your main keyword near the beginning.
          </p>
          <p>
            <strong>Meta Description:</strong> Keep between 120-155 characters. Write compelling copy that encourages clicks.
          </p>
          <p>
            <strong>URL Structure:</strong> Use short, descriptive URLs with keywords separated by hyphens.
          </p>
        </div>
      </div>
    </div>
  );
}
