import { SeoAnalysisResponse, MetaTag } from '@shared/schema';
import MetaTagItem from './MetaTagItem';
import { Code, Share, Settings, FileText, CheckCircle, AlertCircle, XCircle } from 'lucide-react';
import { useState } from 'react';

interface MetaTagsTabProps {
  analysisResult: SeoAnalysisResponse;
}

export default function MetaTagsTab({ analysisResult }: MetaTagsTabProps) {
  const { metaTags } = analysisResult;
  const [expandedSection, setExpandedSection] = useState<string | null>(null);

  // Count issues by category
  const countIssues = (tags: MetaTag[], status: string) => {
    return tags.filter(tag => tag.status === status).length;
  };

  // Group meta tags by category
  const basicTags = [metaTags.title, metaTags.description, metaTags.canonical];
  const socialTags = [metaTags.ogTitle, metaTags.ogImage, metaTags.twitterCard, metaTags.ogDescription, metaTags.twitterImage];
  const technicalTags = [metaTags.robots, metaTags.viewport, metaTags.charset];

  // Count issues
  const basicIssues = {
    error: countIssues(basicTags, 'error'),
    warning: countIssues(basicTags, 'warning'),
    good: countIssues(basicTags, 'good')
  };
  const socialIssues = {
    error: countIssues(socialTags, 'error'),
    warning: countIssues(socialTags, 'warning'),
    good: countIssues(socialTags, 'good')
  };
  const technicalIssues = {
    error: countIssues(technicalTags, 'error'),
    warning: countIssues(technicalTags, 'warning'),
    good: countIssues(technicalTags, 'good')
  };

  const toggleSection = (section: string) => {
    if (expandedSection === section) {
      setExpandedSection(null);
    } else {
      setExpandedSection(section);
    }
  };

  // Helper to determine if a section should be expanded
  const isSectionExpanded = (section: string) => {
    // If on mobile, only expand if explicitly selected, otherwise default to open on desktop
    return expandedSection === section || (expandedSection === null);
  };

  const renderStatusPill = (errors: number, warnings: number, good: number) => {
    if (errors > 0) {
      return (
        <span className="text-xs bg-red-100 text-red-800 px-2 py-1 rounded-full flex items-center">
          <XCircle className="h-3 w-3 mr-1" />
          {errors} {errors === 1 ? 'issue' : 'issues'}
        </span>
      );
    } else if (warnings > 0) {
      return (
        <span className="text-xs bg-amber-100 text-amber-800 px-2 py-1 rounded-full flex items-center">
          <AlertCircle className="h-3 w-3 mr-1" />
          {warnings} {warnings === 1 ? 'warning' : 'warnings'}
        </span>
      );
    } else {
      return (
        <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full flex items-center">
          <CheckCircle className="h-3 w-3 mr-1" />
          All good
        </span>
      );
    }
  };

  return (
    <div className="bg-white p-4 sm:p-6 rounded-lg shadow-sm border border-gray-200">
      <h3 className="text-lg font-semibold mb-4">SEO Meta Tags Analysis</h3>

      {/* Basic Meta Tags */}
      <div className="mb-6 group">
        <div 
          className="flex justify-between items-center mb-3 cursor-pointer sm:cursor-default transition-all hover:bg-emerald-50 hover:border-emerald-500 hover:shadow-lg group"
          onClick={() => toggleSection('basic')}
        >
          <h4 className="text-md font-medium flex items-center">
            <FileText className="h-4 w-4 mr-2" />
            Basic Meta Tags
          </h4>
          <div className="flex items-center">
            {renderStatusPill(basicIssues.error, basicIssues.warning, basicIssues.good)}
            <div className="ml-2 text-gray-400 sm:hidden">
              {isSectionExpanded('basic') ? '−' : '+'}
            </div>
          </div>
        </div>
        {isSectionExpanded('basic') && (
          <div className="space-y-4">
            <MetaTagItem
              title="Title Tag"
              type="title"
              tag={metaTags.title}
              goodDescription="Well-optimized title (50-60 characters)"
              warningDescription="Title is too short (less than 30 characters)"
              errorDescription="Title is too long (more than 60 characters) or missing"
              tooltip="Title tags should be 50-60 characters long and include your main keyword."
            />

            <MetaTagItem
              title="Meta Description"
              type="description"
              tag={metaTags.description}
              goodDescription="Well-optimized description (120-160 characters)"
              warningDescription="Description is too short (less than 120 characters)"
              errorDescription="Description is too long (more than 160 characters) or missing"
              tooltip="Meta descriptions should be 120-160 characters long and provide a concise summary of the page."
            />

            <MetaTagItem
              title="Canonical URL"
              type="canonical"
              tag={metaTags.canonical}
              goodDescription="Proper canonical URL is set"
              warningDescription="Canonical URL doesn't match the current URL"
              errorDescription="No canonical URL found"
              tooltip="Canonical URLs help prevent duplicate content issues by specifying the preferred version of a page."
            />
          </div>
        )}
      </div>

      {/* Social Media Tags */}
      <div className="mb-6 group">
        <div 
          className="flex justify-between items-center mb-3 cursor-pointer sm:cursor-default transition-all hover:bg-emerald-50 hover:border-emerald-500 hover:shadow-lg group"
          onClick={() => toggleSection('social')}
        >
          <h4 className="text-md font-medium flex items-center">
            <Share className="h-4 w-4 mr-2" />
            Social Media Tags
          </h4>
          <div className="flex items-center">
            {renderStatusPill(socialIssues.error, socialIssues.warning, socialIssues.good)}
            <div className="ml-2 text-gray-400 sm:hidden">
              {isSectionExpanded('social') ? '−' : '+'}
            </div>
          </div>
        </div>
        {isSectionExpanded('social') && (
          <div className="space-y-4">
            <MetaTagItem
              title="og:title"
              type="ogTitle"
              tag={metaTags.ogTitle}
              goodDescription="Open Graph title is properly set"
              warningDescription="Open Graph title could be improved"
              errorDescription="No Open Graph title found"
              tooltip="The og:title tag controls how your page title appears when shared on Facebook and other platforms."
            />

            <MetaTagItem
              title="og:description"
              type="ogDescription"
              tag={metaTags.ogDescription}
              goodDescription="Open Graph description is properly set"
              warningDescription="Open Graph description could be improved"
              errorDescription="No Open Graph description found"
              tooltip="The og:description tag controls how your page description appears when shared on Facebook and other platforms."
            />

            <MetaTagItem
              title="og:image"
              type="ogImage"
              tag={metaTags.ogImage}
              goodDescription="Open Graph image is properly set"
              warningDescription="Open Graph image might not be optimal"
              errorDescription="No Open Graph image found"
              tooltip="The og:image tag defines the image shown when your content is shared on social media. Recommended size is 1200×630 pixels."
            />

            <MetaTagItem
              title="twitter:card"
              type="twitterCard"
              tag={metaTags.twitterCard}
              goodDescription="Twitter card type is defined"
              warningDescription="Twitter card type might not be optimal"
              errorDescription="No Twitter card type found"
              tooltip="The twitter:card tag controls the appearance of your content when shared on Twitter. Types include summary, summary_large_image, app, or player."
            />

            <MetaTagItem
              title="twitter:image"
              type="twitterImage"
              tag={metaTags.twitterImage}
              goodDescription="Twitter image is properly set"
              warningDescription="Twitter image might not be optimal"
              errorDescription="No Twitter image found"
              tooltip="The twitter:image tag defines the image shown when your content is shared on Twitter."
            />
          </div>
        )}
      </div>

      {/* Technical SEO Tags */}
      <div className="group">
        <div 
          className="flex justify-between items-center mb-3 cursor-pointer sm:cursor-default transition-all hover:bg-emerald-50 hover:border-emerald-500 hover:shadow-lg group"
          onClick={() => toggleSection('technical')}
        >
          <h4 className="text-md font-medium flex items-center">
            <Settings className="h-4 w-4 mr-2" />
            Technical SEO Tags
          </h4>
          <div className="flex items-center">
            {renderStatusPill(technicalIssues.error, technicalIssues.warning, technicalIssues.good)}
            <div className="ml-2 text-gray-400 sm:hidden">
              {isSectionExpanded('technical') ? '−' : '+'}
            </div>
          </div>
        </div>
        {isSectionExpanded('technical') && (
          <div className="space-y-4">
            <MetaTagItem
              title="Robots Tag"
              type="robots"
              tag={metaTags.robots}
              goodDescription="Page is properly indexable"
              warningDescription="Page has indexing limitations"
              errorDescription="Page is blocked from indexing"
              tooltip="The robots meta tag tells search engines whether to index your page and follow its links."
            />

            <MetaTagItem
              title="Viewport Tag"
              type="viewport"
              tag={metaTags.viewport}
              goodDescription="Viewport is properly configured"
              warningDescription="Viewport has non-standard configuration"
              errorDescription="No viewport meta tag found"
              tooltip="The viewport meta tag ensures your site is mobile-friendly, which is critical for SEO."
            />

            <MetaTagItem
              title="Character Set"
              type="charset"
              tag={metaTags.charset}
              goodDescription="Character encoding is properly defined"
              warningDescription="Non-standard character encoding"
              errorDescription="No character encoding defined"
              tooltip="The charset meta tag defines the character encoding for your page, ensuring text displays correctly."
            />
          </div>
        )}
      </div>
    </div>
  );
}