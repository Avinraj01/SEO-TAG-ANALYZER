
import { SeoAnalysisResponse } from '@shared/schema';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement } from 'chart.js';
import { Pie, Bar } from 'react-chartjs-2';
import { BarChart, ChevronDown, ChevronUp } from 'lucide-react';
import { useState } from 'react';

ChartJS.register(ArcElement, CategoryScale, LinearScale, BarElement, Tooltip, Legend);

interface SeoStatisticsProps {
  analysisResult: SeoAnalysisResponse;
}

export default function SeoStatistics({ analysisResult }: SeoStatisticsProps) {
  
  const { metaTags } = analysisResult;

  const basicSeoScore = [
    metaTags.title.status === 'good' ? 1 : 0,
    metaTags.description.status === 'good' ? 1 : 0,
    metaTags.canonical.status === 'good' ? 1 : 0,
    metaTags.robots.status === 'good' ? 1 : 0,
  ].reduce((a, b) => a + b, 0) * 25;

  const socialMediaScore = [
    metaTags.ogTitle.status === 'good' ? 1 : 0,
    metaTags.ogDescription.status === 'good' ? 1 : 0,
    metaTags.ogImage.status === 'good' ? 1 : 0,
    metaTags.twitterCard.status === 'good' ? 1 : 0,
  ].reduce((a, b) => a + b, 0) * 25;

  const technicalSeoScore = [
    metaTags.charset.status === 'good' ? 1 : 0,
    metaTags.viewport.status === 'good' ? 1 : 0,
  ].reduce((a, b) => a + b, 0) * 50;

  const pieData = {
    labels: ['Basic SEO', 'Social Media', 'Technical SEO'],
    datasets: [{
      data: [basicSeoScore, socialMediaScore, technicalSeoScore],
      backgroundColor: ['#22c55e', '#3b82f6', '#f59e0b'],
      borderColor: ['#16a34a', '#2563eb', '#d97706'],
      borderWidth: 1,
    }],
  };

  const barData = {
    labels: ['Basic SEO', 'Social Media', 'Technical SEO'],
    datasets: [{
      label: 'Category Scores',
      data: [basicSeoScore, socialMediaScore, technicalSeoScore],
      backgroundColor: ['#22c55e80', '#3b82f680', '#f59e0b80'],
      borderColor: ['#16a34a', '#2563eb', '#d97706'],
      borderWidth: 1,
    }],
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
      <h3 className="text-lg font-medium flex items-center mb-4">
        <BarChart className="mr-2 h-5 w-5 text-primary" />
        SEO Performance Statistics
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="aspect-square w-full">
            <h4 className="text-center text-sm font-medium mb-2">Score Distribution</h4>
            <div className="h-[300px] w-full">
              <Pie data={pieData} options={{ 
                responsive: true,
                maintainAspectRatio: false,
              }} />
            </div>
          </div>
          <div className="aspect-square w-full">
            <h4 className="text-center text-sm font-medium mb-2">Category Comparison</h4>
            <div className="h-[300px] w-full">
              <Bar data={barData} options={{ 
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                  y: {
                    beginAtZero: true,
                    max: 100,
                    title: {
                      display: true,
                      text: 'Score'
                    }
                  }
                }
              }} />
            </div>
          </div>
        </div>
    </div>
  );
}
