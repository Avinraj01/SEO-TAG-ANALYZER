import { SeoAnalysisResponse } from '@shared/schema';
import { CheckCircle, AlertCircle, InfoIcon, FileText, Share, Settings, BarChart } from 'lucide-react';
import { CircularProgress } from '@/components/ui/circular-progress';
import CategorySummary from './CategorySummary';
import SeoStatistics from './SeoStatistics';

interface ResultsSummaryProps {
  analysisResult: SeoAnalysisResponse;
}

import ScoreConfetti from './ScoreConfetti';

export default function ResultsSummary({ analysisResult }: ResultsSummaryProps) {
  const { url, overallScore, criticalIssues, warnings, passedChecks, metaTags } = analysisResult;

  // Group meta tags by category
  const basicTags = [metaTags.title, metaTags.description, metaTags.canonical];
  const socialTags = [metaTags.ogTitle, metaTags.ogImage, metaTags.twitterCard, metaTags.ogDescription, metaTags.twitterImage, metaTags.ogType];
  const technicalTags = [metaTags.robots, metaTags.viewport, metaTags.charset];

  // Determine score color
  const getScoreColor = () => {
    if (overallScore < 50) return '#ef4444'; // red-500
    if (overallScore >= 80) return '#10b981'; // emerald-500
    return '#f59e0b'; // amber-500
  };

  const scoreColorClass = overallScore < 50 
    ? 'text-red-500' 
    : overallScore >= 80 
      ? 'text-emerald-500' 
      : 'text-amber-500';

  // Determine status icons
  const getScoreIcon = () => {
    if (overallScore >= 80) return <CheckCircle className="text-emerald-500" />;
    if (overallScore >= 50) return <InfoIcon className="text-amber-500" />;
    return <AlertCircle className="text-red-500" />;
  };

  // Get the SEO recommendation based on score
  const getSeoRecommendation = () => {
    if (overallScore >= 80) {
      return "Your page has strong SEO fundamentals! Keep maintaining these standards.";
    } else if (overallScore >= 50) {
      return "Your page has decent SEO, but there's room for improvement in several areas.";
    } else {
      return "Your page needs significant SEO improvements to rank well in search engines.";
    }
  };

  return (
    <div className="mb-6">
      <ScoreConfetti score={overallScore} /> {/* Confetti animation */}
      {/* Header with URL and timestamp */}
      <div className="bg-blue-500 p-6 rounded-t-lg shadow-sm border border-blue-700 border-b-0 text-white relative"> {/* Changed header background color */}
        <div className="flex items-center justify-between mb-2 flex-wrap gap-2">
          <h2 className="text-lg md:text-xl font-semibold">
            Analysis Results for <span className="font-medium break-all underline decoration-2">{url}</span>
          </h2>
          <span className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded">
            Analyzed {new Date().toLocaleString()}
          </span>
        </div>
        <p className="text-sm">{getSeoRecommendation()}</p>
      </div>

      {/* Overall Statistics Section */}
      <div className="bg-white p-6 rounded-b-lg shadow-sm border border-gray-200 mb-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          {/* Overall Score Card */}
          <div className="bg-gray-50 hover:bg-emerald-700 transition-colors duration-200 rounded-lg p-4 border border-gray-200 hover:border-emerald-800 flex flex-col items-center justify-center group cursor-pointer">
            <p className="text-sm text-gray-500 group-hover:text-white mb-2">Overall Score</p>
            <CircularProgress 
              value={overallScore} 
              size={90} 
              strokeWidth={10}
              color={getScoreColor()}
            >
              <div className="flex flex-col items-center">
                <span className={`text-2xl font-bold ${scoreColorClass} group-hover:text-white`}>{overallScore}%</span>
                <span className="mt-1">
                  {getScoreIcon()}
                </span>
              </div>
            </CircularProgress>
          </div>

          {/* Critical Issues Card */}
          <div className="bg-gray-50 hover:bg-emerald-700 transition-colors duration-200 rounded-lg p-5 border border-gray-200 hover:border-emerald-800 flex flex-col group cursor-pointer">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm text-gray-500 group-hover:text-white mb-1">Critical Issues</p>
                <p className={`text-2xl font-bold text-red-500 group-hover:text-white`}>
                  {criticalIssues}
                </p>
              </div>
              <span className="h-6 w-6">
                {criticalIssues === 0 
                  ? <CheckCircle className="text-emerald-500 group-hover:text-white" /> 
                  : <AlertCircle className="text-red-500 group-hover:text-white" />}
              </span>
            </div>
            <p className="text-xs text-gray-500 group-hover:text-white mt-2">
              {criticalIssues === 0 
                ? "No critical issues found! Your page performs well." 
                : `${criticalIssues} critical issue${criticalIssues !== 1 ? 's' : ''} need attention.`}
            </p>
          </div>

          {/* Warnings Card */}
          <div className="bg-gray-50 hover:bg-emerald-700 transition-colors duration-200 rounded-lg p-5 border border-gray-200 hover:border-emerald-800 flex flex-col group cursor-pointer">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm text-gray-500 group-hover:text-white mb-1">Warnings</p>
                <p className={`text-2xl font-bold text-amber-500 group-hover:text-white`}>
                  {warnings}
                </p>
              </div>
              <span className="h-6 w-6">
                {warnings === 0 
                  ? <CheckCircle className="text-emerald-500 group-hover:text-white" /> 
                  : <InfoIcon className="text-amber-500 group-hover:text-white" />}
              </span>
            </div>
            <p className="text-xs text-gray-500 group-hover:text-white mt-2">
              {warnings === 0 
                ? "No warnings found! Your page meets recommendations." 
                : `${warnings} warning${warnings !== 1 ? 's' : ''} could be improved.`}
            </p>
          </div>

          {/* Passed Checks Card */}
          <div className="bg-gray-50 hover:bg-emerald-700 transition-colors duration-200 rounded-lg p-5 border border-gray-200 hover:border-emerald-800 flex flex-col group cursor-pointer">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm text-gray-500 group-hover:text-white mb-1">Passed Checks</p>
                <p className="text-2xl font-bold text-emerald-500 group-hover:text-white">{passedChecks}</p>
              </div>
              <CheckCircle className="text-emerald-500 group-hover:text-white h-6 w-6" />
            </div>
            <p className="text-xs text-gray-500 group-hover:text-white mt-2">
              {passedChecks} element{passedChecks !== 1 ? 's' : ''} successfully passed all SEO checks.
            </p>
          </div>
        </div>

        {/* Category Summaries Section */}
        <div className="mt-6">
          <h3 className="text-lg font-medium mb-4 flex items-center">
            <BarChart className="mr-2 h-5 w-5 text-primary" />
            Category Performance
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <CategorySummary 
              title="Basic SEO" 
              icon={<FileText className="h-5 w-5" />}
              tags={basicTags}
              description="Essential tags that influence search rankings and click-through rates."
            />

            <CategorySummary 
              title="Social Media" 
              icon={<Share className="h-5 w-5" />}
              tags={socialTags}
              description="Tags that control how your content appears when shared on social platforms."
            />

            <CategorySummary 
              title="Technical SEO" 
              icon={<Settings className="h-5 w-5" />}
              tags={technicalTags}
              description="Technical configurations that affect indexing and proper display."
            />
          </div>
        </div>

        {/* SEO Performance Statistics Section */}
        <div className="mt-6">
          <SeoStatistics analysisResult={analysisResult} />
        </div>
      </div>
    </div>
  );
}