import { useState, useEffect } from 'react';
import URLInput from '@/components/URLInput';
import ResultsSummary from '@/components/ResultsSummary';
import TabNavigation from '@/components/TabNavigation';
import MetaTagsTab from '@/components/MetaTagsTab';
import GooglePreviewTab from '@/components/GooglePreviewTab';
import SocialPreviewTab from '@/components/SocialPreviewTab';
import AppTutorial from '@/components/AppTutorial';
import { SeoAnalysisResponse } from '@shared/schema';
import { Github, Menu, X, ArrowUp, Info } from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

export default function Home() {
  const [activeTab, setActiveTab] = useState('meta-tags');
  const [analysisResult, setAnalysisResult] = useState<SeoAnalysisResponse | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [showTutorial, setShowTutorial] = useState(false);
  const isMobile = useIsMobile();
  const { toast } = useToast();

  // Handle scroll to top button visibility
  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleAnalysisComplete = (result: SeoAnalysisResponse) => {
    setAnalysisResult(result);
    // Reset to the meta-tags tab when a new analysis is completed
    setActiveTab('meta-tags');
    // Close mobile menu if open
    if (mobileMenuOpen) setMobileMenuOpen(false);
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Tutorial for first-time users */}
      <AppTutorial open={showTutorial} setOpen={setShowTutorial} />
      
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8"></circle>
                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
              </svg>
              <h1 className="text-xl font-bold text-gray-900">SEO Tag Analyzer</h1>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-4 text-sm">
              <button 
                onClick={() => setShowTutorial(true)}
                className="text-gray-500 hover:text-primary flex items-center transition-colors"
              >
                <Info className="h-4 w-4 mr-1" />
                Tutorial
              </button>
              <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-primary flex items-center">
                <Github className="h-4 w-4 mr-1" />
                GitHub
              </a>
            </div>
            
            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 rounded-full text-gray-500 hover:text-primary hover:bg-gray-100 transition-colors"
              >
                {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </div>
          </div>
          
          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden mt-3 pt-3 border-t border-gray-200">
              <div className="flex flex-col space-y-3 pb-2">
                <button
                  onClick={() => {
                    setShowTutorial(true);
                    setMobileMenuOpen(false);
                  }}
                  className="text-gray-500 hover:text-primary flex items-center px-2 py-1 text-left"
                >
                  <Info className="h-4 w-4 mr-2" />
                  How to Use (Tutorial)
                </button>
                <a
                  href="https://github.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-500 hover:text-primary flex items-center px-2 py-1"
                >
                  <Github className="h-4 w-4 mr-2" />
                  GitHub Repository
                </a>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-8">
        {/* URL Input Section */}
        <URLInput onAnalysisComplete={handleAnalysisComplete} />

        {/* Results Section (only shows after URL is analyzed) */}
        {analysisResult && (
          <>
            <ResultsSummary analysisResult={analysisResult} />
            
            <TabNavigation activeTab={activeTab} setActiveTab={setActiveTab} />
            
            {/* Tab Content */}
            {activeTab === 'meta-tags' && <MetaTagsTab analysisResult={analysisResult} />}
            {activeTab === 'google-preview' && <GooglePreviewTab analysisResult={analysisResult} />}
            {activeTab === 'social-preview' && <SocialPreviewTab analysisResult={analysisResult} />}
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="md:flex md:items-center md:justify-between">
            <div className="flex justify-center md:justify-start space-x-6">
              <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-gray-500">
                <span className="sr-only">GitHub</span>
                <Github className="h-6 w-6" />
              </a>
            </div>
            <p className="mt-4 text-center text-sm text-gray-500 md:mt-0 md:text-right">
              &copy; {new Date().getFullYear()} SEO Tag Analyzer. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
      
      {/* Scroll to top button */}
      {showScrollTop && (
        <Button
          onClick={scrollToTop}
          className="fixed bottom-6 right-6 h-10 w-10 rounded-full p-0 shadow-lg"
          aria-label="Scroll to top"
        >
          <ArrowUp size={20} />
        </Button>
      )}
    </div>
  );
}
