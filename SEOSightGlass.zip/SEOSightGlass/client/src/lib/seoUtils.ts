import { MetaTagStatus } from '@shared/schema';

// Utility functions for SEO analysis

/**
 * Checks if a title is within optimal length range
 */
export function analyzeTitleLength(title: string | null): MetaTagStatus {
  if (!title) return 'error';
  
  const length = title.length;
  if (length > 60) return 'error';
  if (length < 30) return 'warning';
  return 'good';
}

/**
 * Checks if a description is within optimal length range
 */
export function analyzeDescriptionLength(description: string | null): MetaTagStatus {
  if (!description) return 'error';
  
  const length = description.length;
  if (length > 160) return 'error';
  if (length < 120) return 'warning';
  return 'good';
}

/**
 * Checks if a canonical URL is present and properly formatted
 */
export function analyzeCanonical(canonical: string | null, currentUrl: string): MetaTagStatus {
  if (!canonical) return 'error';
  if (!canonical.includes(new URL(currentUrl).hostname)) return 'warning';
  return 'good';
}

/**
 * Checks if robots meta tag allows indexing
 */
export function analyzeRobots(robots: string | null): MetaTagStatus {
  if (!robots) return 'warning';
  if (robots.includes('noindex')) return 'error';
  return 'good';
}

/**
 * Calculate overall SEO score based on meta tag statuses
 */
export function calculateOverallScore(
  metaTags: Record<string, { status: MetaTagStatus }>
): number {
  // Count the different status types
  const counts = Object.values(metaTags).reduce(
    (acc, { status }) => {
      acc[status]++;
      return acc;
    },
    { good: 0, warning: 0, error: 0 } as Record<MetaTagStatus, number>
  );
  
  // Weight the score (good = 100%, warning = 50%, error = 0%)
  const totalChecks = Object.keys(metaTags).length;
  const weightedScore = 
    (counts.good * 100 + counts.warning * 50) / totalChecks;
  
  return Math.round(Math.max(0, Math.min(100, weightedScore)));
}
