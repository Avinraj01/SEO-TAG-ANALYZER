import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Search, FileText, BarChart, Share, ChevronRight } from 'lucide-react';

// Tutorial steps with descriptions
const tutorialSteps = [
  {
    title: "Welcome to SEO Analyzer",
    description: "This tool helps you analyze and improve your website's SEO performance. Let's take a quick tour!",
    icon: <BarChart className="h-8 w-8 text-primary" />,
  },
  {
    title: "Enter Any URL",
    description: "Start by entering a website URL in the search bar. Our tool will analyze its SEO meta tags and provide detailed feedback.",
    icon: <Search className="h-8 w-8 text-primary" />,
  },
  {
    title: "Review SEO Score",
    description: "After analysis, you'll see an overall score and category breakdowns highlighting your strengths and areas for improvement.",
    icon: <BarChart className="h-8 w-8 text-primary" />,
  },
  {
    title: "Check Meta Tags",
    description: "The Meta Tags tab shows detailed information about your page's title, description, and other important SEO elements.",
    icon: <FileText className="h-8 w-8 text-primary" />,
  },
  {
    title: "Preview Appearances",
    description: "See how your page will appear in Google search results and when shared on social media platforms.",
    icon: <Share className="h-8 w-8 text-primary" />,
  }
];

interface AppTutorialProps {
  open?: boolean;
  setOpen?: (open: boolean) => void;
}

export default function AppTutorial({ open: externalOpen, setOpen: setExternalOpen }: AppTutorialProps = {}) {
  const [internalOpen, setInternalOpen] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  
  // Use either the external or internal state for open
  const open = externalOpen !== undefined ? externalOpen : internalOpen;
  const setOpen = setExternalOpen || setInternalOpen;
  
  // Show tutorial immediately on first visit
  useEffect(() => {
    setOpen(true);
  }, []);
  
  // Reset step when dialog opens
  useEffect(() => {
    if (open) {
      setCurrentStep(0);
    }
  }, [open]);
  
  const handleNext = () => {
    if (currentStep < tutorialSteps.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      setOpen(false);
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="mx-auto mb-4 bg-primary/10 p-3 rounded-full">
            {tutorialSteps[currentStep].icon}
          </div>
          <DialogTitle className="text-center text-xl">
            {tutorialSteps[currentStep].title}
          </DialogTitle>
          <DialogDescription className="text-center pt-2">
            {tutorialSteps[currentStep].description}
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex justify-center mt-4 mb-2">
          {tutorialSteps.map((_, index) => (
            <div 
              key={index}
              className={`h-1.5 rounded-full mx-1 transition-all ${
                index === currentStep ? 'w-6 bg-primary' : 'w-2 bg-gray-200'
              }`}
            />
          ))}
        </div>
        
        <DialogFooter className="mt-4 sm:justify-between flex">
          <Button
            variant="outline"
            onClick={() => setOpen(false)}
          >
            Skip
          </Button>
          <Button onClick={handleNext}>
            {currentStep < tutorialSteps.length - 1 ? (
              <>
                Next
                <ChevronRight className="h-4 w-4 ml-1" />
              </>
            ) : (
              'Get Started'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}